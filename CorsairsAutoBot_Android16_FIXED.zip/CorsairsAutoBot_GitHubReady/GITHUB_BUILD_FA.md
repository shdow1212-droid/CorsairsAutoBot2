# ساخت APK با GitHub Actions

1. تمام فایل‌های این پوشه را در ریشه Repository آپلود کنید.
2. مطمئن شوید `app/` و `build.gradle.kts` در ریشه هستند.
3. به تب Actions بروید.
4. Workflow با نام Build APK را باز کنید.
5. روی Run workflow بزنید.
6. پس از سبز شدن Build، وارد اجرای همان Workflow شوید.
7. پایین صفحه در بخش Artifacts فایل CorsairsAutoBot-debug را دریافت کنید.
8. ZIP مربوط به Artifact را باز کنید و APK داخل آن را نصب کنید.

این Workflow خودش Gradle 8.7 و JDK 17 را روی سرور GitHub آماده می‌کند؛ پس نیازی به AndroidIDE یا کامپیوتر ندارید.
