package com.mandasan.corsairsbot

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Corsairs Auto Bot\n\nنسخه Android 16"
            textSize = 24f
            setPadding(0, 0, 0, 40)
        }

        val info = TextView(this).apply {
            text = """
                1) دکمه زیر را بزن.
                2) سرویس Corsairs Auto Bot را در Accessibility روشن کن.
                3) بازی را باز کن.
                4) سرویس به‌صورت خودکار شروع به تحلیل صفحه می‌کند.

                برای توقف، Accessibility را خاموش کن.
            """.trimIndent()
            textSize = 17f
            setPadding(0, 0, 0, 30)
        }

        val settings = Button(this).apply {
            text = "باز کردن Accessibility"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val test = Button(this).apply {
            text = "باز کردن تنظیمات برنامه"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(settings)
        layout.addView(test)
        setContentView(layout)
    }
}
