package com.mandasan.corsairsbot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CorsairsAccessibilityService extends AccessibilityService {
    private static volatile boolean running = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    private long lastAction = 0;
    private boolean busy = false;

    public static void setRunning(boolean value) { running = value; }
    public static boolean isRunning() { return running; }

    @Override public void onServiceConnected() { super.onServiceConnected(); }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { recognizer.close(); super.onDestroy(); }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!running || busy) return;
        long now = System.currentTimeMillis();
        if (now - lastAction < 450) return;
        if (event == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            solveFromAccessibilityTree();
            captureAndSolve();
        }
    }

    private void solveFromAccessibilityTree() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        ArrayList<NodeText> nodes = new ArrayList<>();
        collect(root, nodes);
        for (NodeText n : nodes) {
            Integer answer = parseExpression(n.text);
            if (answer == null) continue;
            for (NodeText option : nodes) {
                if (isInteger(option.text) && Integer.parseInt(option.text.trim()) == answer) {
                    Rect r = option.bounds;
                    if (r.width() > 0 && r.height() > 0) {
                        tap(r.centerX(), r.centerY());
                        return;
                    }
                }
            }
        }
    }

    private void collect(AccessibilityNodeInfo node, List<NodeText> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        if (t != null && t.length() > 0) {
            Rect r = new Rect(); node.getBoundsInScreen(r);
            out.add(new NodeText(t.toString(), r));
        }
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out);
    }

    private void captureAndSolve() {
        if (android.os.Build.VERSION.SDK_INT < 30 || busy) return;
        busy = true;
        takeScreenshot(0, getMainExecutor(), new AccessibilityService.TakeScreenshotCallback() {
            @Override public void onSuccess(AccessibilityService.ScreenshotResult result) {
                Bitmap b = result.getBitmap();
                InputImage image = InputImage.fromBitmap(b, 0);
                recognizer.process(image)
                    .addOnSuccessListener(text -> processOcr(text))
                    .addOnCompleteListener(x -> { busy = false; b.recycle(); });
            }
            @Override public void onFailure(int errorCode) { busy = false; }
        });
    }

    private void processOcr(Text text) {
        if (!running) return;
        List<Text.Element> elements = new ArrayList<>();
        for (Text.TextBlock block : text.getTextBlocks())
            for (Text.Line line : block.getLines())
                elements.addAll(line.getElements());

        Integer answer = null;
        for (Text.TextBlock block : text.getTextBlocks()) {
            Integer a = parseExpression(block.getText());
            if (a != null) { answer = a; break; }
            for (Text.Line line : block.getLines()) {
                a = parseExpression(line.getText());
                if (a != null) { answer = a; break; }
            }
            if (answer != null) break;
        }
        if (answer == null) return;

        for (Text.Element e : elements) {
            String s = normalize(e.getText());
            if (isInteger(s) && Integer.parseInt(s) == answer) {
                Rect r = e.getBoundingBox();
                if (r != null && r.width() > 0 && r.height() > 0) {
                    tap(r.centerX(), r.centerY());
                    return;
                }
            }
        }
    }

    private Integer parseExpression(String raw) {
        if (raw == null) return null;
        String s = normalize(raw).replace("O", "0").replace("I", "1");
        Pattern p = Pattern.compile("(-?\\d{1,5})\\s*([+\\-xX×*÷/])\\s*(-?\\d{1,5})");
        Matcher m = p.matcher(s);
        if (!m.find()) return null;
        int a, b; try { a = Integer.parseInt(m.group(1)); b = Integer.parseInt(m.group(3)); } catch (Exception e) { return null; }
        switch (m.group(2)) {
            case "+": return a + b;
            case "-": return a - b;
            case "x": case "X": case "×": case "*": return a * b;
            case "÷": case "/": return b == 0 ? null : a / b;
            default: return null;
        }
    }

    private String normalize(String s) {
        return s.replace('−','-').replace('–','-').replace('—','-').trim();
    }
    private boolean isInteger(String s) { return s != null && s.trim().matches("-?\\d{1,6}"); }

    private void tap(int x, int y) {
        if (!running || System.currentTimeMillis() - lastAction < 450) return;
        lastAction = System.currentTimeMillis();
        Path path = new Path(); path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(path, 0, 35)).build();
        dispatchGesture(gesture, null, null);
    }

    private static class NodeText {
        final String text; final Rect bounds;
        NodeText(String t, Rect b) { text = t; bounds = b; }
    }
}
