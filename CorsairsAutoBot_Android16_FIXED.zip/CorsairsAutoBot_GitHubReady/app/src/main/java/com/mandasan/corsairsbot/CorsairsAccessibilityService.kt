package com.mandasan.corsairsbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Prototype detector for the Corsairs game shown by the user.
 *
 * It deliberately uses only Android framework APIs:
 * - AccessibilityService.takeScreenshot()
 * - Bitmap pixel analysis
 * - AccessibilityService.dispatchGesture()
 *
 * No OpenCV/native libraries are required.
 */
class CorsairsAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var active = false
    private var lastFrame: FrameState? = null
    private var lastActionMs = 0L

    // The game in the supplied recording occupies roughly the upper ~70% of the screen.
    private val gameBottomFraction = 0.73f

    override fun onServiceConnected() {
        super.onServiceConnected()
        active = true
        scheduleNextFrame(250L)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // We don't need UI events; screenshots drive the detector.
    }

    override fun onInterrupt() {
        active = false
        handler.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        active = false
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun scheduleNextFrame(delay: Long) {
        if (!active) return
        handler.postDelayed({ captureFrame() }, delay)
    }

    private fun captureFrame() {
        if (!active) return

        // Android's screenshot API is rate-limited; 250 ms is intentionally conservative.
        takeScreenshot(
            android.view.Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    val hardware = Bitmap.wrapHardwareBuffer(
                        result.hardwareBuffer,
                        result.colorSpace
                    )

                    val bitmap = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                    hardware?.recycle()
                    result.hardwareBuffer.close()

                    if (bitmap != null) {
                        try {
                            analyze(bitmap)
                        } finally {
                            bitmap.recycle()
                        }
                    }
                    scheduleNextFrame(250L)
                }

                override fun onFailure(errorCode: Int) {
                    scheduleNextFrame(500L)
                }
            }
        )
    }

    private fun analyze(bitmap: Bitmap) {
        val w = bitmap.width
        val h = bitmap.height
        if (w < 300 || h < 500) return

        // Center estimated from the supplied recording. We keep it proportional
        // so it survives different resolutions/aspect ratios.
        val cx = w * 0.50f
        val cy = h * 0.415f

        val ship = detectShip(bitmap, cx, cy)
        val projectile = detectProjectile(bitmap, cx, cy)

        val now = System.currentTimeMillis()
        val previous = lastFrame

        if (ship != null && projectile != null) {
            val shipAngle = atan2(ship.y - cy, ship.x - cx)
            val projectileAngle = atan2(projectile.y - cy, projectile.x - cx)
            val projectileRadius = hypot(
                projectile.x - cx,
                projectile.y - cy
            )

            var shipAngularVelocity = 0f
            if (previous?.shipAngle != null) {
                shipAngularVelocity = normalizeAngle(
                    shipAngle - previous.shipAngle!!
                ) / max(1L, now - previous.timeMs).toFloat() * 1000f
            }

            var projectileRadialVelocity = 0f
            if (previous?.projectileRadius != null) {
                projectileRadialVelocity =
                    (projectileRadius - previous.projectileRadius!!) /
                    max(1L, now - previous.timeMs).toFloat() * 1000f
            }

            // The ship runs on the outer ring. In the recording this is about
            // 0.39-0.48 of screen width; use the current ship position when known.
            val orbitRadius = hypot(ship.x - cx, ship.y - cy)

            // If the projectile is moving inward, estimate when it reaches the orbit.
            if (projectileRadialVelocity < -15f) {
                val distanceToOrbit = projectileRadius - orbitRadius
                val secondsToOrbit = distanceToOrbit / (-projectileRadialVelocity)

                if (secondsToOrbit in 0.0..1.2) {
                    val predictedShipAngle =
                        shipAngle + shipAngularVelocity * secondsToOrbit

                    val angularSeparation =
                        abs(normalizeAngle(projectileAngle - predictedShipAngle))

                    // Safety margin around the ship.
                    if (angularSeparation < 0.18f) {
                        reverseDirection()
                    }
                }
            }

            lastFrame = FrameState(
                timeMs = now,
                shipAngle = shipAngle,
                projectileRadius = projectileRadius
            )
        } else {
            // Keep old state briefly, but don't act without a confident detection.
            if (now - (previous?.timeMs ?: 0L) > 1200L) {
                lastFrame = null
            }
        }
    }

    /**
     * Detect the brown/tan ship in the outer orbit.
     */
    private fun detectShip(bitmap: Bitmap, cx: Float, cy: Float): Point? {
        val step = 4
        val minR = min(bitmap.width, bitmap.height) * 0.18f
        val maxR = min(bitmap.width, bitmap.height) * 0.38f

        var sx = 0.0
        var sy = 0.0
        var count = 0

        var y = 200
        val maxY = (bitmap.height * gameBottomFraction).toInt()

        while (y < maxY) {
            var x = 0
            while (x < bitmap.width) {
                val dx = x - cx
                val dy = y - cy
                val r = hypot(dx, dy)

                if (r in minR..maxR) {
                    val c = bitmap.getPixel(x, y)
                    val red = Color.red(c)
                    val green = Color.green(c)
                    val blue = Color.blue(c)

                    // Brown/tan pixels characteristic of the ship.
                    if (red in 105..230 &&
                        green in 65..155 &&
                        blue in 35..125 &&
                        red > green + 20 &&
                        green > blue + 15
                    ) {
                        sx += x
                        sy += y
                        count++
                    }
                }
                x += step
            }
            y += step
        }

        if (count < 8) return null
        return Point((sx / count).toFloat(), (sy / count).toFloat())
    }

    /**
     * Detect a dark gray projectile outside the central planet.
     * We use a coarse scan and choose the strongest candidate away from
     * the central gear/planet.
     */
    private fun detectProjectile(bitmap: Bitmap, cx: Float, cy: Float): Point? {
        val step = 4
        val minR = min(bitmap.width, bitmap.height) * 0.12f
        val maxR = min(bitmap.width, bitmap.height) * 0.43f

        var best: Candidate? = null

        // Candidate bins are coarse screen cells.
        val bins = HashMap<Long, IntArray>()

        var y = 230
        val maxY = (bitmap.height * gameBottomFraction).toInt()

        while (y < maxY) {
            var x = 0
            while (x < bitmap.width) {
                val dx = x - cx
                val dy = y - cy
                val r = hypot(dx, dy)

                if (r in minR..maxR) {
                    val c = bitmap.getPixel(x, y)
                    val red = Color.red(c)
                    val green = Color.green(c)
                    val blue = Color.blue(c)

                    val grayish =
                        abs(red - green) < 18 &&
                        abs(green - blue) < 18

                    if (grayish && red in 45..155) {
                        val bx = x / 32
                        val by = y / 32
                        val key = (bx.toLong() shl 32) xor (by.toLong() and 0xffffffffL)
                        val a = bins.getOrPut(key) { intArrayOf(0, 0, 0) }
                        a[0] += 1
                        a[1] += x
                        a[2] += y
                    }
                }
                x += step
            }
            y += step
        }

        for ((_, a) in bins) {
            val n = a[0]
            if (n < 8) continue

            val px = a[1].toFloat() / n
            val py = a[2].toFloat() / n
            val r = hypot(px - cx, py - cy)

            // Ignore the central gear: it is much closer to the center.
            if (r < min(bitmap.width, bitmap.height) * 0.16f) continue

            val candidate = Candidate(px, py, n)
            if (best == null || candidate.score > best!!.score) {
                best = candidate
            }
        }

        return best?.let { Point(it.x, it.y) }
    }

    /**
     * The in-game control reverses the ship's direction.
     * We tap the center of the large two-arrow button shown in the recording.
     */
    private fun reverseDirection() {
        val now = System.currentTimeMillis()
        if (now - lastActionMs < 650L) return
        lastActionMs = now

        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.50f
        val y = dm.heightPixels * 0.835f

        val path = Path().apply {
            moveTo(x, y)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    0L,
                    60L
                )
            )
            .build()

        dispatchGesture(gesture, null, null)
    }

    private fun normalizeAngle(a: Float): Float {
        var x = a
        while (x > PI) x -= (2f * PI).toFloat()
        while (x < -PI) x += (2f * PI).toFloat()
        return x
    }

    private data class Point(val x: Float, val y: Float)

    private data class Candidate(
        val x: Float,
        val y: Float,
        val pixels: Int
    ) {
        val score: Int get() = pixels
    }

    private data class FrameState(
        val timeMs: Long,
        val shipAngle: Float,
        val projectileRadius: Float
    )
}
