package com.mandasan.corsairsbot;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("Corsairs Auto Bot\nAndroid 16");
        title.setTextSize(24);
        root.addView(title);

        status = new TextView(this);
        status.setText("\n1) دسترسی Accessibility را فعال کن.\n2) بازی را باز کن.\n3) Start را بزن.");
        status.setTextSize(16);
        root.addView(status);

        Button settings = new Button(this);
        settings.setText("باز کردن Accessibility");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(settings);

        Button start = new Button(this);
        start.setText("Start Bot");
        start.setOnClickListener(v -> {
            CorsairsAccessibilityService.setRunning(true);
            status.setText("Bot روشن است. بازی را باز نگه دار.");
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop Bot");
        stop.setOnClickListener(v -> {
            CorsairsAccessibilityService.setRunning(false);
            status.setText("Bot خاموش شد.");
        });
        root.addView(stop);

        setContentView(root);
    }
}
