plugins {
    id("com.android.application")
}

android {
    namespace = "com.mandasan.corsairsbot"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mandasan.corsairsbot"
        minSdk = 30
        targetSdk = 36
        versionCode = 2
        versionName = "1.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.core:core:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
