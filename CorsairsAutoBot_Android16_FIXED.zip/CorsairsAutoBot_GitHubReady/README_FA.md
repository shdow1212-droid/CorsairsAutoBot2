# Corsairs Auto Bot — Android 16

نسخهٔ بازسازی‌شده و قابل Build با GitHub Actions.

این نسخه از AccessibilityService و OCR استفاده می‌کند: عبارت ریاضی روی صفحه را پیدا می‌کند، جواب را حساب می‌کند و اگر همان عدد به‌عنوان گزینه روی صفحه دیده شود، روی آن ضربه می‌زند.

## نصب
1. Workflow با نام **Build APK** را اجرا کن یا یک Commit جدید بزن.
2. بعد از سبز شدن Build، وارد همان Run شو.
3. از بخش **Artifacts** فایل `CorsairsAutoBot-debug` را بگیر.
4. ZIP را باز کن و APK را نصب کن.
5. در Settings > Accessibility، سرویس Corsairs Auto Bot را فعال کن.
6. برنامه را باز کن و **Start Bot** را بزن.

هدف پروژه Android 16 / API 36 است و حداقل Android 11 را پشتیبانی می‌کند.
